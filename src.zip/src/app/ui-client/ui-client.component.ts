import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ui-client',
  templateUrl: './ui-client.component.html',
  styleUrls: ['./ui-client.component.css']
})
export class UiClientComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
