import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-owner',
  templateUrl: './login-owner.component.html',
  styleUrls: ['./login-owner.component.css']
})
export class LoginOwnerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
