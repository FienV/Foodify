import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ui-owner',
  templateUrl: './ui-owner.component.html',
  styleUrls: ['./ui-owner.component.css']
})
export class UiOwnerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
